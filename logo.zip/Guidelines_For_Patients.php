<?php include "include/header.php";?>
            
<!-- BREADCRUMBS -->


<div class="bread-crumb-wrap ibc-wrap-2">
    <div class="container padding_remove">
        <div class="inner-page-title-wrap col-xs-12 col-md-12 col-sm-12">
            <div class="bread-heading">
                <h3>Guidelines For Patient</h3>
            </div>
            <div class="bread-crumb pull-right">
                <ul>
                    <li><a href="index.html">Home</a></li>
                    <li><a href="Guidelines_For_Patients.html">Guidelines For Patient</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid managment_contents">
    <div class="container">
        <div class="row">
            <div class="bhoechie-tab-container departments">
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 bhoechie-tab-menu">
                    <div class="list-group">
                        <a href="Admission_Procedure.html" class="list-group-item">
                            <h4 class="fa fa-user fontawsme"></h4><span>Admission Procedure</span>
                        </a>
                        <a href="During_Stay.html" class="list-group-item">
                            <h4 class="fa fa-user fontawsme"></h4><span>During Stay</span>
                        </a>
                        <a href="Discharge_Procedure.html" class="list-group-item">
                            <h4 class="fa fa-h-square fontawsme"></h4><span>Discharge Procedure</span>
                        </a>
                       <a href="Timing_Schedule.html" class="list-group-item">
                            <h4 class="fa fa-plus-square fontawsme"></h4><span>Timing & Schedule</span>
                        </a>
                        <a href="Doctor_Schedule.html" class="list-group-item">
                            <h4 class="fa fa-plus-square fontawsme"></h4><span>Doctors OPD Schedule</span>
                        </a>
                        <a href="Guidelines_For_Patients.html" class="list-group-item  active">
                            <h4 class="fa fa-plus-square fontawsme"></h4><span>Guidelines For Patient</span>
                        </a>
                        <a href="Guidelines_For_Visitors.html" class="list-group-item">
                            <h4 class="fa fa-plus-square fontawsme"></h4><span>Guidelines For Visitors</span>
                        </a>
                                          
                        <a href="Billing_Procedure.html" class="list-group-item">
                            <h4 class="fa fa-eye fontawsme"></h4><span>Billing Procedure</span>
                        </a>
<!--                        <a href="Make_An_Appointment.php" target="_blank" class="list-group-item">
                            <h4 class="fa fa-h-square fontawsme"></h4><span>Make An Appointment</span>
                        </a>-->
                       
<!--                        <a href="Success_Stories.php" class="list-group-item">
                            <h4 class="fa fa-plus-square fontawsme"></h4><span>Success Stories</span>
                        </a>-->
                        <a href="Corporate_Tie_Ups.html" class="list-group-item">
                            <h4 class="fa fa-plus-square fontawsme"></h4><span>Corporate Tie-Ups</span>
                        </a>
                        <a href="Quality_Safety.html" class="list-group-item">
                            <h4 class="fa fa-shield fontawsme"></h4><span>Quality & Safety</span>
                        </a>
<!--                        <a href="Online_Bill_Payment.php" class="list-group-item">
                            <h4 class="fa fa-plus-square fontawsme"></h4><span>Online Bill Payment</span>
                        </a>-->
                      
                    </div> 
                </div>

                <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12 bhoechie-tab">
                    <!-- train section -->
                    <div class="bhoechie-tab-content active">
                        <div class="col-sm-12 col-md-12 col-lg-12">
                            <h4 style="font-size:18px; color:red; border-bottom: 2px solid black; padding-bottom: 5px;">Mandatory Guidelines for Patients !</h4> 
                            <div class="row">
                                <div class="col-sm-12 col-md-12 col-lg-12">
                                    <div class="row" id="slider">
                                <div class="col-sm-12 col-md-12 col-lg-12"  id="carousel-bounding-box">
                                    <div class="carousel slide" id="myCarousel">
                                        <img src="images/Services/Guidelines_Patients.jpg" style="width:798px;" >
                                    </div>
                                </div>
                                    </div><hr>
                                      <p style="text-align: justify; font-size:13.5px;">
                                       1.	At Astha Hospital, Patient gets a comfortable and smooth process for the OPD or the Admission without being biased to any of them. 
                                    </p>
                                    <p style="text-align: justify; font-size:13.5px;">
                                     2.	We don’t discriminate anyone on the basis of any religion, caste, color, nationality, disability, age, sex or any other thing and gives a safe environment to everyone.
                                    </p>
                                    <p style="text-align: justify; font-size:13.5px;">   
                                     3.	We treat our Patients with respect and courtesy being non-judgmental or by any special preferences or cultural needs that influences the Patient Illness.
                                    </p>
                                    <p style="text-align: justify; font-size:13.5px;">
                                     4.	We give our Patient a friendly environment in terms of understanding their illness or their problems, a proper consultancy team is there to help them.
                                    </p>
                                    <p style="text-align: justify; font-size:13.5px;">
                                     5.	We inform the Patient of their illness and the diagnosis and do take care of their illness under the consideration of the proper specialist as per the availability in the Hospital.
                                    </p>
                                    <p style="text-align: justify; font-size:13.5px;">
                                     6.	We direct the Physicians, Doctors, Consultants and the Staffs to be fully informed of the Medical Care that are understandable by him/her.
                                    </p>
                                    <p style="text-align: justify; font-size:13.5px;">
                                     7.	We inform the Patient about the risk or the side effect of the proposed treatment of their Illness. 
                                    </p>
                                    <p style="text-align: justify; font-size:13.5px;">
                                     8.	We refuse the treatment at any point if the Patient or their attendants ask to stop or the consequences of the illness or treatment have been explained.
                                    </p>
                                    <p style="text-align: justify; font-size:13.5px;">
                                     9.	We inform the Patient if there will be any change in the Patient Clinical Conditions.
                                    </p>
                                    <p style="text-align: justify; font-size:13.5px;">
                                     10. We inform the Patient if there will be any financial implications or changes appear during the Treatment of the Patient.
                                    </p>
                                  
                                </div>
                            </div>
                            
                            
                        </div>
                    </div> 
                </div>

            </div>
        </div>
    </div>
</div>



<footer class="footer">

    <div class="container">
        <div class="row">
            <!--Foot widget-->
            <div class="col-xs-12 col-sm-6 col-md-3 foot-widget">
                <a href="index.html"><div class="foot-logo col-xs-12 no-pad">
                       
                    </div></a>

                   <address class="foot-address">
                  <div class="col-xs-12 padding_remove"><i class="fa fa-globe address-icons"></i><span>Astha Hospital</span></div>
                    <div class="col-xs-12 padding_remove"><i class="fa fa-file address-icons"></i><span>49/163A, Jawahar Lal Nehru Road, Tagore Town, Allahabad.</span></div>
                    <div class="col-xs-12 padding_remove"><i class="fa fa-phone address-icons"></i><span>+91 - 9838086888</span></div>
                    <div class="col-xs-12 padding_remove"><i class="fa fa-envelope address-icons"></i><span>info@Asthahospital.org</span></div>
                    <div class="col-xs-12 padding_remove"><a href="http://www.Asthahospital.org/"style="color:black">Visitors No:-&nbsp;<img src="http://www.reliablecounter.com/count.php?page=www.Asthahospital.org1&amp;digit=style/odometers/5/&amp;reloads=0" alt="" title="" border="0"   style="width:50px;"></a></div>
                </address>
            </div>

            <!--Foot widget-->
            <div class="col-xs-12 col-sm-6 col-md-3 recent-post-foot foot-widget">
                <div class="foot-widget-title">Quick Links</div>
                <ul>
                    <li><a href="Doctors.html">Doctors</a></li>
                    <li><a href="Departments.html">Departments</a></li>
                    <li><a href="Intensive_Care_Unit.html">Services</a></li> 
                    <li><a href="Patient_Rooms.html">Patient Rooms</a></li> 
                    <li><a href="About_Us.html">Who We Are</a></li> 
                    <li><a href="Why_Us-2.html">Why Us</a></li>
                    <li><a href="Doctor_Schedule.html">OPD Schedule</a></li>
                   
                   
                </ul>
            </div>


            <!--Foot widget-->
            <div class="col-xs-12 col-sm-6 col-md-3 recent-post-foot foot-widget">
                <div class="foot-widget-title" style="font-family: Montserrat;">Disclaimer</div>
                <ul>
                    <li><a href="Terms_Conditions.html">Terms & Conditions</a></li>
                    <li><a href="Privacy_Policy.html">Privacy Policy</a></li>
                     <li><a href="Guidelines_For_Patients.html">Guidelines for Patients</a></li> 
                    <li><a href="Guidelines_For_Visitors.html">Guidelines for Visitors</a></li> 



                   
                </ul>
            </div>

            <!--Foot widget-->
            <div class="col-xs-12 col-sm-6 col-md-3 foot-widget">
               
                <div class="foot-widget-title">social media</div>
                <div class="social-wrap">
 <div class="fb-page" data-href="https://www.facebook.com/Asthahospitalallahabad" data-tabs="timeline" data-height="150" data-small-header="true" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="false"><blockquote cite="https://www.facebook.com/Asthahospitalallahabad" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/Asthahospitalallahabad">Astha Hospital</a></blockquote></div>
                </div>
            </div>

        </div>
    </div>       

</footer>
<div class="bottom-footer">
    <div class="container">

        <div class="row">
            <!--Foot widget-->
            <div class="col-xs-12 col-sm-12 col-md-12 foot-widget-bottom">
                <p class="col-xs-12 col-sm-6 col-md-9 no-pad">Astha Hospital © 2012 - 2018 | All Rights Reserved.</p>
                <p class="foot-menu col-sm-6 col-xs-12 col-md-3 no-pad" style="text-align: right;">
                    Designed By: <a target="_blank" href="https://www.swankinfytech.in/index.html" target="_blank" style="color:#fff;">Swank InfyTech</a>                      
                </p>
            </div>
        </div>
    </div> 
</div>

</div>

</body>

<!-- Mirrored from Asthahospital.org/Guidelines_For_Patients.php by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 24 Jul 2023 08:12:17 GMT -->
</html>
<script src="../ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.10.3.custom.min.js"></script>  
<script type="text/javascript" src="js/jquery.themepunch.tools.min.js"></script>
<script type="text/javascript" src="js/jquery.themepunch.revolution.min.js"></script>
<script type="text/javascript" src="js/jquery.scrollUp.min.js"></script>
<script type="text/javascript" src="js/jquery.sticky.min.js"></script>
<script type="text/javascript" src="js/wow.min.js"></script>
<script type="text/javascript" src="js/jquery.flexisel.min.js"></script>
<script type="text/javascript" src="js/jquery.imedica.min.js"></script>
<script type="text/javascript" src="js/custom-imedicajs.min.js"></script>
<script type="text/javascript" src="js/custom.js"></script>

<script src="js/owl.carousel.min.js"></script>

</body>
</html>