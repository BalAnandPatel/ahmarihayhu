<?php include "include/header.php"; ?>
        <!-- MEET OUR DOCTORS -->
        <!-- BANNER START -->
        <!-- BANNER START -->
        <div class="container-fluid">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 bannerslider padding_remove">
                    <div class="container full-width-container ihome-banner">
                        <div class="banner">
                            <ul>
                                <!-- THE BOXSLIDE EFFECT EXAMPLES  WITH LINK ON THE MAIN SLIDE EXAMPLE -->
                                <li data-transition="papercut" data-slotamount="7">
                                    <!-- MAIN IMAGE -->
                                    <img src="images/Hospital/slider1.jpg" alt="slidebg1" data-bgfit="cover"
                                        data-bgposition="left top" data-bgrepeat="no-repeat">
                                    <!-- LAYER NR. 5 -->

                                    <!-- LAYER NR. 6 -->
                                    <div class="tp-caption bluebg-t2 sfr skewtoright imed-sl1" data-x="60" data-y="12"
                                        data-hoffset="-10" data-speed="1000" data-start="2900"
                                        data-easing="Back.easeOut" data-endspeed="400" data-endeasing="Power1.easeIn">
                                        <p style="color: black; font-family: 'Arimo', sans-serif; font-size:32px;">
                                            Welcome to the Astha Hospital !<br>
                                            <span style="color:blue; font-size:26px;"> Tagore Town, Allahabad.</span>
                                    </div>
                                    <!-- LAYER NR. 7 -->

                                    <!-- LAYER NR. 8 -->
                                    <div class="tp-caption s1-but customin skewtoright imed-sl1" data-x="300"
                                        data-y="110" data-hoffset="205" data-speed="1000"
                                        data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                                        data-start="3900" data-easing="Back.easeOut" data-endspeed="400"
                                        data-endeasing="Power1.easeIn">
                                        <a href="About_Us.php">
                                            <img src="images/Hospital/readmorebuttonblue.png" style="width:200px;">
                                        </a>
                                    </div>
                                </li>
                                <li data-transition="papercut" data-slotamount="7">
                                    <!-- MAIN IMAGE -->
                                    <img src="images/Hospital/slider2.jpg" alt="slidebg1" data-bgfit="cover"
                                        data-bgposition="left top" data-bgrepeat="no-repeat">
                                    <!-- LAYER NR. 2 -->
                                    <div class="tp-caption skewfromright stl imed-sl1" data-x="left" data-y="65"
                                        data-hoffset="-20" data-speed="1500" data-start="1300"
                                        data-easing="Power4.easeOut" data-endspeed="400" data-endeasing="Power1.easeIn">
                                        <img src="images/new-slider/s2-img2.png" alt="" class="img-responsive">
                                    </div>


                                    <!-- LAYER NR. 3 -->
                                    <div class="tp-caption lft stt imed-sl1" data-x="left" data-y="173"
                                        data-hoffset="583" data-speed="1400" data-start="1600"
                                        data-easing="Power4.easeOut" data-endspeed="400" data-endeasing="Power1.easeIn">
                                        <img src="images/new-slider/s3-ic1.png" alt="" class="img-responsive">
                                    </div>

                                    <!-- LAYER NR. 3 -->
                                    <div class="tp-caption lft stt imed-sl1" data-x="left" data-y="143"
                                        data-hoffset="493" data-speed="1400" data-start="1900"
                                        data-easing="Power4.easeOut" data-endspeed="400" data-endeasing="Power1.easeIn">
                                        <img src="images/new-slider/s3-ic2.png" alt="" class="img-responsive">
                                    </div>

                                    <!-- LAYER NR. 3 -->
                                    <div class="tp-caption lft stt imed-sl1" data-x="left" data-y="115"
                                        data-hoffset="408" data-speed="1400" data-start="2200"
                                        data-easing="Power4.easeOut" data-endspeed="400" data-endeasing="Power1.easeIn">
                                        <img src="images/new-slider/s3-ic3.png" alt="" class="img-responsive">
                                    </div>


                                    <!-- LAYER NR. 3 -->
                                    <div class="tp-caption lft stt imed-sl1" data-x="left" data-y="89"
                                        data-hoffset="332" data-speed="1400" data-start="2500"
                                        data-easing="Power4.easeOut" data-endspeed="400" data-endeasing="Power1.easeIn">
                                        <img src="images/new-slider/s3-ic4.png" alt="" class="img-responsive">
                                    </div>

                                    <!-- LAYER NR. 3 -->
                                    <div class="tp-caption lft stt imed-sl1" data-x="left" data-y="68"
                                        data-hoffset="268" data-speed="1400" data-start="2800"
                                        data-easing="Power4.easeOut" data-endspeed="400" data-endeasing="Power1.easeIn">
                                        <img src="images/new-slider/s3-ic5.png" alt="" class="img-responsive">
                                    </div>

                                    <!-- LAYER NR. 3 -->
                                    <div class="tp-caption lft stt imed-sl1" data-x="left" data-y="47"
                                        data-hoffset="204" data-speed="1400" data-start="3100"
                                        data-easing="Power4.easeOut" data-endspeed="400" data-endeasing="Power1.easeIn">
                                        <img src="images/new-slider/s3-ic6.png" alt="" class="img-responsive">
                                    </div>

                                    <!-- LAYER NR. 3 -->
                                    <div class="tp-caption lft stt imed-sl1" data-x="left" data-y="222"
                                        data-hoffset="478" data-speed="1400" data-start="3400"
                                        data-easing="Power4.easeOut" data-endspeed="400" data-endeasing="Power1.easeIn">
                                        <img src="images/new-slider/s3-ic7.png" alt="" class="img-responsive">
                                    </div>


                                    <!-- LAYER NR. 3 -->
                                    <div class="tp-caption lft stt imed-sl1" data-x="left" data-y="177"
                                        data-hoffset="370" data-speed="1400" data-start="3700"
                                        data-easing="Power4.easeOut" data-endspeed="400" data-endeasing="Power1.easeIn">
                                        <img src="images/new-slider/s3-ic8.png" alt="" class="img-responsive">
                                    </div>

                                    <!-- LAYER NR. 3 -->
                                    <div class="tp-caption lft stt imed-sl1" data-x="left" data-y="140"
                                        data-hoffset="278" data-speed="1400" data-start="4000"
                                        data-easing="Power4.easeOut" data-endspeed="400" data-endeasing="Power1.easeIn">
                                        <img src="images/new-slider/s3-ic9.png" alt="" class="img-responsive">
                                    </div>

                                    <!-- LAYER NR. 3 -->
                                    <div class="tp-caption lft stt imed-sl1" data-x="left" data-y="108"
                                        data-hoffset="198" data-speed="1400" data-start="4300"
                                        data-easing="Power4.easeOut" data-endspeed="400" data-endeasing="Power1.easeIn">
                                        <img src="images/new-slider/s3-ic10.png" alt="" class="img-responsive">
                                    </div>

                                    <!-- LAYER NR. 3 -->
                                    <div class="tp-caption lft stt imed-sl1" data-x="left" data-y="76"
                                        data-hoffset="120" data-speed="1400" data-start="4600"
                                        data-easing="Power4.easeOut" data-endspeed="400" data-endeasing="Power1.easeIn">
                                        <img src="images/new-slider/s3-ic11.png" alt="" class="img-responsive">
                                    </div>

                                    <!-- LAYER NR. 3 -->
                                    <div class="tp-caption lft stt imed-sl1" data-x="left" data-y="292"
                                        data-hoffset="398" data-speed="1400" data-start="4900"
                                        data-easing="Power4.easeOut" data-endspeed="400" data-endeasing="Power1.easeIn">
                                        <img src="images/new-slider/s3-ic12.png" alt="" class="img-responsive">
                                    </div>

                                    <!-- LAYER NR. 3 -->
                                    <div class="tp-caption lft stt imed-sl1" data-x="left" data-y="240"
                                        data-hoffset="294" data-speed="1400" data-start="5200"
                                        data-easing="Power4.easeOut" data-endspeed="400" data-endeasing="Power1.easeIn">
                                        <img src="images/new-slider/s3-ic13.png" alt="" class="img-responsive">
                                    </div>

                                    <!-- LAYER NR. 3 -->
                                    <div class="tp-caption lft stt imed-sl1" data-x="left" data-y="196"
                                        data-hoffset="203" data-speed="1400" data-start="5500"
                                        data-easing="Power4.easeOut" data-endspeed="400" data-endeasing="Power1.easeIn">
                                        <img src="images/new-slider/s3-ic14.png" alt="" class="img-responsive">
                                    </div>

                                    <!-- LAYER NR. 3 -->
                                    <div class="tp-caption lft stt imed-sl1" data-x="left" data-y="158"
                                        data-hoffset="123" data-speed="1400" data-start="5800"
                                        data-easing="Power4.easeOut" data-endspeed="400" data-endeasing="Power1.easeIn">
                                        <img src="images/new-slider/s3-ic15.png" alt="" class="img-responsive">
                                    </div>

                                    <!-- LAYER NR. 3 -->
                                    <div class="tp-caption lft stt imed-sl1" data-x="left" data-y="123"
                                        data-hoffset="51" data-speed="1400" data-start="6100"
                                        data-easing="Power4.easeOut" data-endspeed="400" data-endeasing="Power1.easeIn">
                                        <img src="images/new-slider/s3-ic16.png" alt="" class="img-responsive">
                                    </div>



                                    <!-- LAYER NR. 6 -->
                                    <div class="tp-caption whitebg-t1 sfr skewtoright imed-sl1" data-x="right"
                                        data-y="70" data-hoffset="-60" data-speed="1500" data-start="6500"
                                        data-easing="Back.easeOut" data-endspeed="400" data-endeasing="Power1.easeIn">
                                        <p style="color:yellow; font-family: 'Arimo', sans-serif; font-size:30px;">
                                            Get all the Medical Facilities<br>under One Roof !</p>
                                    </div>


                                    <!-- LAYER NR. 7 -->

                                    <!-- LAYER NR. 8 -->
                                    <div class="tp-caption whitebg-t3 sfr skewtoright imed-sl1" data-x="right"
                                        data-y="170" data-hoffset="-60" data-speed="1500" data-start="7100"
                                        data-easing="Back.easeOut" data-endspeed="400" data-endeasing="Power1.easeIn">
                                        <p style="color:red; font-family: 'Arimo', sans-serif; font-size:26px;">
                                            <b> Check our all the Services.</b>
                                    </div>


                                    <!-- LAYER NR. 9 -->
                                    <div class="tp-caption s1-but customin skewtoright imed-sl1" data-x="820"
                                        data-y="230" data-hoffset="205" data-speed="1500"
                                        data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                                        data-start="7400" data-easing="Back.easeOut" data-endspeed="400"
                                        data-endeasing="Power1.easeIn"><a href="Intensive_Care_Unit.php">
                                            <img src="images/new-slider/enquire-now%20(1).png" style="width:180px"></a>
                                    </div>




                                </li>


                                <li data-transition="papercut" data-slotamount="7">

                                    <!-- MAIN IMAGE -->
                                    <img src="images/Hospital/slider3.jpg" alt="slidebg1" data-bgfit="cover"
                                        data-bgposition="left top" data-bgrepeat="no-repeat">
                                    <!-- LAYER NR. 6 -->
                                    <div class="tp-caption bluebg-t2 sfr skewtoright imed-sl1" data-x="right"
                                        data-y="100" data-hoffset="-10" data-speed="1000" data-start="2900"
                                        data-easing="Back.easeOut" data-endspeed="400" data-endeasing="Power1.easeIn">
                                        <p style="color:black; font-family: 'Arimo', sans-serif; font-size:26px;">

                                            <b> Experience the Best Consultants of the City !</b>
                                        <p>
                                    </div>
                                    <!-- LAYER NR. 7 -->
                                    <div class="tp-caption bluebg-t3 sfr skewtoright imed-sl1" data-x="right"
                                        data-y="160" data-hoffset="-60" data-speed="1000" data-start="3400"
                                        data-easing="Back.easeOut" data-endspeed="400" data-endeasing="Power1.easeIn">
                                        <p style="color:red; font-family: 'Arimo', sans-serif; font-size:22px;">
                                            Check our all the Departments under one Roof !</p>
                                    </div>
                                    <!-- LAYER NR. 8 -->
                                    <div class="tp-caption s1-but customin skewtoright imed-sl1" data-x="820"
                                        data-y="230" data-hoffset="205" data-speed="1000"
                                        data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                                        data-start="3900" data-easing="Back.easeOut" data-endspeed="400"
                                        data-endeasing="Power1.easeIn">
                                        <a href="Departments.php">
                                            <img src="images/new-slider/read-more-button-red.png"
                                                style="width:250px; height:75px;"></a>
                                    </div>
                                </li>

                                <li data-transition="papercut" data-slotamount="7">

                                    <!-- MAIN IMAGE -->
                                    <img src="images/Hospital/slider4.jpg" alt="slidebg1" data-bgfit="cover"
                                        data-bgposition="left top" data-bgrepeat="no-repeat">

                                    <!-- LAYER NR. 5 -->
                                    <div class="tp-caption bluebg-t1 sfr skewtoright imed-sl1" data-x="right"
                                        data-y="115" data-hoffset="-40" data-speed="1000" data-start="4800"
                                        data-easing="Back.easeOut" data-endspeed="400" data-endeasing="Power1.easeIn">
                                        <p style="color:black; font-family: 'Arimo', sans-serif; font-size:26px;">
                                            <b> Excellent Patient Rooms !</b>
                                        </p>
                                    </div>
                                    <!-- LAYER NR. 6 -->
                                    <div class="tp-caption bluebg-t2 sfr skewtoright imed-sl1" data-x="right"
                                        data-y="160" data-hoffset="10" data-speed="1000" data-start="5200"
                                        data-easing="Back.easeOut" data-endspeed="400" data-endeasing="Power1.easeIn">
                                        <p style="color:yellow; font-family: 'Arimo', sans-serif; font-size:22px;">
                                            <b>
                                                Equipped with Hygiene Facility. </b>
                                        </p>
                                    </div>
                                    <!-- LAYER NR. 7 -->
                                    <div class="tp-caption bluebg-t3 sfr skewtoright imed-sl1" data-x="right"
                                        data-y="220" data-hoffset="-40" data-speed="1000" data-start="5500"
                                        data-easing="Back.easeOut" data-endspeed="400" data-endeasing="Power1.easeIn">
                                        <p style="color:red; font-family: 'Arimo', sans-serif; font-size:20px;">

                                            We have Different - Different Type of Rooms equipped with all the Facilities
                                            & Services.</p>
                                    </div>
                                    <!-- LAYER NR. 8 -->
                                    <div class="tp-caption s1-but customin skewtoright imed-sl1" data-x="center"
                                        data-y="260" data-hoffset="225" data-speed="1000"
                                        data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                                        data-start="5700" data-easing="Back.easeOut" data-endspeed="400"
                                        data-endeasing="Power1.easeIn">
                                        <a href="Patient_Rooms.php">
                                            <img src="images/new-slider/enquire-now%20(2).png"
                                                style="width:210px; height:50px;">
                                        </a>
                                    </div>
                                </li>

                                <li data-transition="papercut" data-slotamount="7">

                                    <!-- MAIN IMAGE -->
                                    <img src="images/Hospital/slider5.jpg" alt="slidebg1" data-bgfit="cover"
                                        data-bgposition="left top" data-bgrepeat="no-repeat">

                                    <!-- LAYER NR. 5 -->
                                    <div class="tp-caption bluebg-t1 sfr skewtoright imed-sl1" data-x="right"
                                        data-y="115" data-hoffset="-40" data-speed="1000" data-start="4800"
                                        data-easing="Back.easeOut" data-endspeed="400" data-endeasing="Power1.easeIn">
                                        <p style="color:white; font-family: 'Arimo', sans-serif; font-size:26px;">
                                            <b>Doctors OPD Timing !</b>
                                        </p>
                                    </div>
                                    <!-- LAYER NR. 6 -->
                                    <div class="tp-caption bluebg-t2 sfr skewtoright imed-sl1" data-x="right"
                                        data-y="160" data-hoffset="10" data-speed="1000" data-start="5200"
                                        data-easing="Back.easeOut" data-endspeed="400" data-endeasing="Power1.easeIn">
                                        <p style="color:yellow; font-family: 'Arimo', sans-serif; font-size:22px;">
                                            <b>
                                                Check the OPD Timing of each Doctors. </b>
                                        </p>
                                    </div>
                                    <!-- LAYER NR. 7 -->

                                    <!-- LAYER NR. 8 -->
                                    <div class="tp-caption s1-but customin skewtoright imed-sl1" data-x="750"
                                        data-y="220" data-hoffset="225" data-speed="1000"
                                        data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                                        data-start="5700" data-easing="Back.easeOut" data-endspeed="400"
                                        data-endeasing="Power1.easeIn">
                                        <a href="Doctor_Schedule.php">
                                            <img src="images/new-slider/enquire-now%20(2).png"
                                                style="width:210px; height:50px;">
                                        </a>
                                    </div>
                                </li>

                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- APPOINTMENT SECTION -->

        <section class="sec1">
            <div class="container ">
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12 appntmntsec padding_remove">
                        <div class="col-sm-3 col-md-3 col-lg-3">
                            <button type="button" class="btn btn-default hvr-rectangle-out"
                                style="font-family:'Pompiere', cursive; font-size:18px; font-weight: 600; letter-spacing: 2px;">
                                Book an Online Appointment<br>
                                (Click on the Name)
                            </button>
                        </div>
                        <div class="col-sm-3 col-md-3 col-lg-3">
                            <div class="form-group">
                                <p style="font-size:11px;">
                                    <strong style="color:crimson; font-size:14px; font-weight: 400;">
                                    <a href='' target='_blank'>Dr. R. K. Singh</a></strong><br>
                                    M.B.B.S | M.D. | (Pediatric, Physician)
                                </p>
                            </div>
                            <div class="form-group">
                                <p style="font-size:11px;">
                                    <strong style="color:crimson; font-size:14px; font-weight: 400;">
                                    <a href='' target='_blank'>Dr. Sanjay Singh</a></strong><br>
                                            M.B.B.S | D.N.B | (Pediatric, Physician)
                                </p>
                            </div>
                        </div>
                        <div class="col-sm-3 col-md-3 col-lg-3">
                            <div class="form-group">
                                <p style="font-size:11px;">
                                    <strong style="color:crimson; font-size:14px; font-weight: 400;">
                                    <a href='' target='_blank'>Dr.
                                            R. P. PAL</a></strong><br>
                                    M.S. (Surgeon)
                                </p>
                            </div>

                        </div>
                        <div class="col-sm-3 col-md-3 col-lg-3">


                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="sec2">
            <div class="container">
                <div class="row">
                    <h3 class="secheadng2">Meet our doctors
                        <p href="Departments.html" style="float:right; font-size:10px; color:black;">* Move the Cursor
                            Over the Doctor Image for the Detailed View.
                            <br>
                            <a href="Doctors.html" style="float:right; font-size: 15px;">View All</a>
                        </p>
                    </h3>
                    <div class="col-sm-12 col-md-12 col-lg-12 padding_remove">
                        <div id="owl-demo">
                            <div class="item">
                                <div class="feed-img">
                                    <div class="clearfix">
                                        <img src="images/Doctors/Dr_A_Gupta.jpg" alt="Dr. A Gupta"
                                            style="height:315px; padding:4px">
                                    </div>
                                    <div class="feed-btn indi-btn">
                                        <ul>
                                            <!--                                 <li class="blue" style="font-family:'Arimo', sans-serif; font-weight: 400;"><a href="Book_An_Appointment.php">Request An Appointment</a></li>-->
                                            <li class="blue" style="font-family:'Arimo', sans-serif; font-weight: 400;">
                                                <a href="Dr_A_Gupta.html">View Profile</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item_caption">
                                    <p>
                                        <strong style="color:crimson; font-size:16px; font-weight: 400;">Dr.
                                            Gupta</strong><br>
                                        M.D. | DNB | (Nephrology)
                                    </p>
                                </div>
                            </div>
                            <div class="item">
                                <div class="feed-img">
                                    <div class="clearfix">
                                        <img src="images/Doctors/Dr_Neogi.jpg" alt="Dr. Neogi"
                                            style="height:315px; padding:4px">
                                    </div>
                                    <div class="feed-btn indi-btn">
                                        <ul>
                                            <!--                                 <li class="blue" style="font-family:'Arimo', sans-serif; font-weight: 400;"><a href="Book_An_Appointment.php">Request An Appointment</a></li>-->
                                            <li class="blue" style="font-family:'Arimo', sans-serif; font-weight: 400;">
                                                <a href="About_Doctors.html">View Profile</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item_caption">
                                    <p>
                                        <strong style="color:crimson; font-size:16px; font-weight: 400;">Dr.
                                            Neogi</strong><br>
                                        M.S. | FRCS | (Minimal Access Surgery)
                                    </p>
                                </div>
                            </div>

                            <div class="item">
                                <div class="feed-img">
                                    <div class="clearfix">
                                        <img src="images/Doctors/Dr_Sanjay_Asthana.jpg" alt="Dr. Sanjay Asthana"
                                            style="height:315px; padding:4px;">
                                    </div>
                                    <div class="feed-btn indi-btn">
                                        <ul>
                                            <li class="blue" style="font-family:'Arimo', sans-serif; font-weight: 400;">
                                                <a href="http://www.drsanjayaasthana.com/" target='_blank'>Book An
                                                    Appointment</a></li>
                                            <li class="blue" style="font-family:'Arimo', sans-serif; font-weight: 400;">
                                                <a href="Dr_Sanjaya_Asthana.html">View Profile</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item_caption">
                                    <p>
                                        <strong style="color:crimson; font-size:16px; font-weight: 400;">Dr. Sanjay
                                            Asthana</strong><br>
                                        M.S. | M.Ch | (Neurosurgery)
                                    </p>
                                </div>
                            </div>
                            <div class="item">
                                <div class="feed-img">
                                    <div class="clearfix">
                                        <img src="images/Doctors/Dr_Dhanesh_Agrahari1.jpg" alt="Dr.Dhanesh Agrahari"
                                            style="height:315px; padding:4px">
                                    </div>
                                    <div class="feed-btn indi-btn">
                                        <ul>
                                            <li class="blue" style="font-family:'Arimo', sans-serif; font-weight: 400;">
                                                <a href="http://drdhaneshagrahari.com/Appointment.php"
                                                    target="_blank">Request An Appointment</a></li>
                                            <li class="blue" style="font-family:'Arimo', sans-serif; font-weight: 400;">
                                                <a href="Dr_Dhanesh_Agrahari.html">View Profile</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item_caption">
                                    <p>
                                        <strong style="color:crimson; font-size:16px; font-weight: 400;">Dr. Dhanesh
                                            Agrahari</strong><br>
                                        M.S. | M.Ch | (Pediatric Surgeon)
                                    </p>
                                </div>
                            </div>
                            <div class="item">
                                <div class="feed-img">
                                    <div class="clearfix">
                                        <img src="images/Doctors/Dr_J_V_Rai.jpg" alt="Dr. J.V. Rai"
                                            style="height:315px; padding:4px">
                                    </div>
                                    <div class="feed-btn indi-btn">
                                        <ul>
                                            <!--                                 <li class="blue" style="font-family:'Arimo', sans-serif; font-weight: 400;"><a href="Book_An_Appointment.php">Request An Appointment</a></li>-->
                                            <li class="blue" style="font-family:'Arimo', sans-serif; font-weight: 400;">
                                                <a href="About_Doctors.html">View Profile</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item_caption">
                                    <p>
                                        <strong style="color:crimson; font-size:16px; font-weight: 400;">Dr. J. V.
                                            Rai</strong><br>
                                        M.D. | MRCP | (Pediatrics)
                                    </p>
                                </div>
                            </div>

                            <div class="item">
                                <div class="feed-img">
                                    <div class="clearfix">
                                        <img src="images/Doctors/Dr_Alok_Misra.png" alt="Dr. Alok Mishra"
                                            style="height:315px; padding:4px">
                                    </div>
                                    <div class="feed-btn indi-btn">
                                        <ul>
                                            <!--                                 <li class="blue" style="font-family:'Arimo', sans-serif; font-weight: 400;"><a href="Book_An_Appointment.php">Request An Appointment</a></li>-->
                                            <li class="blue" style="font-family:'Arimo', sans-serif; font-weight: 400;">
                                                <a href="About_Doctors.html">View Profile</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item_caption">
                                    <p>
                                        <strong style="color:crimson; font-size:16px; font-weight: 400;">Dr. Alok
                                            Mishra</strong><br>
                                        M.D. | D.M. | (Gastroenterology)
                                    </p>
                                </div>
                            </div>
                            <div class="item">
                                <div class="feed-img">
                                    <div class="clearfix">
                                        <img src="images/Doctors/Dr_Rupam_Sinha1.jpg" alt="Dr. Rupam Sinha"
                                            style="height:315px; padding:4px">
                                    </div>
                                    <div class="feed-btn indi-btn">
                                        <ul>
                                            <!--                                 <li class="blue" style="font-family:'Arimo', sans-serif; font-weight: 400;"><a href="Book_An_Appointment.php">Request An Appointment</a></li>-->
                                            <li class="blue" style="font-family:'Arimo', sans-serif; font-weight: 400;">
                                                <a href="Dr_Rupam_Sinha.html">View Profile</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item_caption">
                                    <p>
                                        <strong style="color:crimson; font-size:16px; font-weight: 400;">Dr. Rupam
                                            Sinha</strong><br>
                                        M.D.
                                    </p>
                                </div>
                            </div>

                            <div class="item">
                                <div class="feed-img">
                                    <div class="clearfix">
                                        <img src="images/Doctors/Dr_Vibhav_Malviya.jpg" alt="Dr. Vibhav Malviya"
                                            style="height:315px; padding:4px">
                                    </div>
                                    <div class="feed-btn indi-btn">
                                        <ul>
                                            <!--                                <li class="blue" style="font-family:'Arimo', sans-serif; font-weight: 400;"><a href="Book_An_Appointment.php">Request An Appointment</a></li>-->
                                            <li class="blue" style="font-family:'Arimo', sans-serif; font-weight: 400;">
                                                <a href="About_Doctors.html">View Profile</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item_caption">
                                    <p>
                                        <strong style="color:crimson; font-size:16px; font-weight: 400;">Dr. Vibhav
                                            Malviya</strong><br>
                                        M.S. | M.Ch. |(Urology)
                                    </p>
                                </div>
                            </div>
                            <div class="item">
                                <div class="feed-img">
                                    <div class="clearfix">
                                        <img src="images/Doctors/Dr_Amrita_Agrahari1.jpg" alt="Dr. Amrita Agrahari"
                                            style="height:315px; padding:4px">
                                    </div>
                                    <div class="feed-btn indi-btn">
                                        <ul>
                                            <li class="blue" style="font-family:'Arimo', sans-serif; font-weight: 400;">
                                                <a href="http://drdhaneshagrahari.com/Appointment.php"
                                                    target="_blank">Request An Appointment</a></li>
                                            <li class="blue" style="font-family:'Arimo', sans-serif; font-weight: 400;">
                                                <a href="Dr_Amrita_Agrahari.html">View Profile</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item_caption">
                                    <p>
                                        <strong style="color:crimson; font-size:16px; font-weight: 400;">Dr. Amrita
                                            Agrahari</strong><br>
                                        DGO | FICMCH | (Gynae.)
                                    </p>
                                </div>
                            </div>
                            <div class="item">
                                <div class="feed-img">
                                    <div class="clearfix">
                                        <img src="images/Doctors/Dr_Smita_Srivastava.jpg" alt="Dr. Smita Srivastava"
                                            style="height:315px; padding:4px">
                                    </div>
                                    <div class="feed-btn indi-btn">
                                        <ul>
                                            <!--                                <li class="blue" style="font-family:'Arimo', sans-serif; font-weight: 400;"><a href="Book_An_Appointment.php">Request An Appointment</a></li>-->
                                            <li class="blue" style="font-family:'Arimo', sans-serif; font-weight: 400;">
                                                <a href="Dr_Smita_Srivastava.html">View Profile</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item_caption">
                                    <p>
                                        <strong style="color:crimson; font-size:16px; font-weight: 400;">Dr. Smita
                                            Srivastava</strong><br>
                                        DGO - DNB | MNAMS | (Gynae.)
                                    </p>
                                </div>
                            </div>
                            <div class="item">
                                <div class="feed-img">
                                    <div class="clearfix">
                                        <img src="images/Doctors/Dr_Urmi_Neogi.jpg" alt="Dr. Urmi Neogi"
                                            style="height:315px; padding:4px">
                                    </div>
                                    <div class="feed-btn indi-btn">
                                        <ul>
                                            <!--                                <li class="blue" style="font-family:'Arimo', sans-serif; font-weight: 400;"><a href="Book_An_Appointment.php">Request An Appointment</a></li>-->
                                            <li class="blue" style="font-family:'Arimo', sans-serif; font-weight: 400;">
                                                <a href="About_Doctors.html">View Profile</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item_caption">
                                    <p>
                                        <strong style="color:crimson; font-size:16px; font-weight: 400;">Dr. Urmi
                                            Neogi</strong><br>
                                        M.S. | (Gynae.)
                                    </p>
                                </div>
                            </div>

                            <div class="item">
                                <div class="feed-img">
                                    <div class="clearfix">
                                        <img src="images/Doctors/Dr_Alpna_Sharma.jpg" alt="Dr. Alpana Sharma"
                                            style="height:315px; padding:4px">
                                    </div>
                                    <div class="feed-btn indi-btn">
                                        <ul>
                                            <!--                                <li class="blue" style="font-family:'Arimo', sans-serif; font-weight: 400;"><a href="Book_An_Appointment.php">Request An Appointment</a></li>-->
                                            <li class="blue" style="font-family:'Arimo', sans-serif; font-weight: 400;">
                                                <a href="About_Doctors.html">View Profile</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item_caption">
                                    <p>
                                        <strong style="color:crimson; font-size:16px; font-weight: 400;">Dr. Alpana
                                            Sharma</strong><br>
                                        M.D. | (Anaesthesia)
                                    </p>
                                </div>
                            </div>

                            <div class="item">
                                <div class="feed-img">
                                    <div class="clearfix">
                                        <img src="images/Doctors/Dr_Shubha_Malviya.jpg" alt="Dr. Shubha Malviya"
                                            style="height:315px; padding:4px">
                                    </div>
                                    <div class="feed-btn indi-btn">
                                        <ul>
                                            <!--                                <li class="blue" style="font-family:'Arimo', sans-serif; font-weight: 400;"><a href="Book_An_Appointment.php">Request An Appointment</a></li>-->
                                            <li class="blue" style="font-family:'Arimo', sans-serif; font-weight: 400;">
                                                <a href="About_Doctors.html">View Profile</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="item_caption">
                                    <p>
                                        <strong style="color:crimson; font-size:16px; font-weight: 400;">Dr. Shubha
                                            Malviya</strong><br>
                                        DCH |(Paediatrics)
                                    </p>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- STILL NOT CONVINCED -->

        <section class="sec3 animatedParent">
            <div class="container">
                <div class="row">
                    <h3 class="secheadng2">Services</h3>

                    <div class="col-sm-3 col-md-3 col-lg-3 sec3sub1 left_remove" data-wow-offset="200"
                        data-wow-delay="0.5s">
                        <h4><!--<i class="fa fa-hospital-o" aria-hidden="true"></i>-->Our Medical Services</h4>
                        <ul>
                            <li><i class="fa fa-ambulance fontcolor" aria-hidden="true"></i><a href="#">Emergency
                                    Services</a></li>
                            <li><i class="fa fa-heart fontcolor" aria-hidden="true"></i><a href="#">Pathology
                                    Services</a></li>
                            <li><i class="fa fa-stethoscope fontcolor" aria-hidden="true"></i><a href="#">Vaccination
                                    Facility</a></li>
                            <li><i class="fa fa-medkit fontcolor" aria-hidden="true"></i><a href="#">Physiotherapy
                                    Unit</a></li>
                            <li><i class="fa fa-lemon-o fontcolor" aria-hidden="true"></i><a href="#">Pharmacy</a></li>
                            <li><i class="fa fa-h-square fontcolor" aria-hidden="true"></i><a href="#">Helpline
                                    Services</a></li>
                            <li><i class="fa fa-medkit fontcolor" aria-hidden="true"></i><a href="#">Health Insurance
                                    Facility</a></li>
                            <li><i class="fa fa-ambulance fontcolor" aria-hidden="true"></i><a href="#">Ambulance
                                    Services with Transport Unit </a></li>
                        </ul>
                    </div>
                    <div class="col-sm-6 col-md-6 col-lg-6 sec3sub2" data-wow-offset="200" data-wow-delay="1.7s">
                        <div class="content-tabs">
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs">
                                <li class="active"><a data-toggle="tab" href="#tab-settings">About Astha</a></li>
                                <li><a data-toggle="tab" class="" href="#tab-home">ICU</a></li>
                                <li><a data-toggle="tab" class="" href="#tab-profile">NICU</a></li>
                                <li><a data-toggle="tab" href="#tab-messages">Pathology</a></li>

                            </ul>
                            <!-- Tab panes -->
                            <div class="tab-content" style="text-align: justify;">
                                <div id="tab-settings" class="tab-pane tab_pane fade in active">
                                    <div class="col-md-3 padding_remove">
                                        <img class="img-responsive tab-img thumbnail"
                                            src="images/Hospital/Hospital_Small.png" alt="Astha Hospital">
                                    </div>
                                    <div class="col-md-9">
                                        <p>
                                            Astha Hospital is the First Wide ranging Multi and Super-Specialty
                                            Hospital of this city with the mission to provide Quality Medical and Health
                                            Care. Astha Hospital is a unit of Prayag Health Care And Research Centre
                                            Pvt. Ltd., one amongst the best healthcare institutes in the eastern Uttar
                                            Pradesh.

                                        </p>
                                    </div>
                                    <p>Astha is the genesis of the dream seen ten years back by few Super-Specialists
                                        of the Allahabad city to provide superspeciality services under one roof. The
                                        dream nurtured and grew within the founder directors of Astha Hospitals
                                        Dr. Sanjay Asthana, Dr. J.V. Rai, Dr. Dhanesh Agrahari, Dr. R.K.Sinha , Dr.
                                        Gupta, Dr. Alok Mishra, Dr. Vibhav Malviya,
                                        & Dr. Neogi until the point of culmination happened in 2012.
                                        Astha hospital has been designed as an energy efficient building that complies
                                        with the ECBC (Energy Conservation Building Code) and sustainable design
                                        concepts have been incorporated in different aspects of the building design.
                                        It offers a convenient location for Patients, their Attendants and Families.
                                    </p>
                                    <a href="About_Us.html"><img src="images/Hospital/readmorebuttonblue.png"
                                            style="width:150px; height:55px; float:right; margin-top:-10px;"></a>
                                </div>

                                <div id="tab-home" class="tab-pane tab_pane fade">
                                    <div class="col-md-3 padding_remove">
                                        <img class="img-responsive tab-img thumbnail"
                                            src="images/Hospital/ICU_Small.png" alt="ICU Section" width="100%">
                                    </div>
                                    <div class="col-md-9">
                                        <p>
                                            ICU - Known as an Intensive Care Unit also known as an Intensive Therapy
                                            Unit or Intensive Treatment Unit (ITU)
                                            or Critical Care Unit (CCU) is a special department of a hospital or health
                                            care facility that provides Intensive Treatment Medicine.
                                        </p>
                                    </div>
                                    <p>&nbsp;
                                        In Astha Hospital, Allahabad - Intensive care units cater to patients with
                                        severe and life-threatening illnesses and
                                        injuries, which require constant, close monitoring and support from specialist
                                        equipment and medications in order to
                                        ensure normal bodily functions. They are staffed by highly trained doctors and
                                        nurses who specialise in caring for critically
                                        ill patients. Here, in Astha, ICU is also distinguished from normal hospital
                                        wards by a higher staff-to-patient ratio
                                        and access to advanced medical resources and equipment that is not routinely
                                        available elsewhere.
                                        Astha Hospital has 16 Bed ICU with Intensive Care and Staff Support.

                                    </p>
                                    <a href="Intensive_Care_Unit.html"><img src="images/Hospital/readmorebuttonblue.png"
                                            style="width:150px; height:55px; float:right; margin-top:-10px;">
                                    </a>
                                </div>
                                <div id="tab-profile" class="tab-pane tab_pane fade">
                                    <div class="col-md-3 padding_remove">
                                        <img class="img-responsive tab-img thumbnail"
                                            src="images/Hospital/NICU_Small_Photo.png" alt="NICU Section" width="100%">
                                    </div>
                                    <div class="col-md-9">
                                        <p>
                                            NICU - is knows as Neonatal Intensive Care Unit also known as an Intensive
                                            Care Nursery (ICN) which is an Intensive - Care Unit specializing
                                            in the care of ill or Premature Newborn Infants.

                                        </p>
                                    </div>
                                    <p>
                                        &nbsp; Astha Hospital has 8 Bed most sophisticated and equipped &nbsp;Neonatal
                                        Intensive Care Unit (NICU) as well as 6 Bed Pediatric &nbsp; Intensive Care Unit
                                        (PICU) with bed side
                                        Central Oxygen & Suction facility, Exchange Transfusion with Pulse - Oxymtery,
                                        Syringe Infusion Pump, and Ventilators etc.
                                    </p>
                                    <a href="NICU.html"><img src="images/Hospital/readmorebuttonblue.png"
                                            style="width:150px; height:55px; float:right; margin-top:-10px;">
                                    </a>
                                </div>
                                <div id="tab-messages" class="tab-pane tab_pane fade">
                                    <div class="col-md-3 padding_remove">
                                        <img class="img-responsive tab-img thumbnail"
                                            src="images/Hospital/Pathology_Small.jpg" alt="image" width="100%">
                                    </div>
                                    <div class="col-md-9">
                                        <p>
                                            Pathology - is concerned with the diagnosis of disease based on the
                                            laboratory analysis of bodily fluids such as blood and
                                            urine, as well as tissues, using the tools of chemistry, clinical
                                            microbiology, hematology and molecular pathology.
                                        </p>
                                    </div>
                                    <p>
                                        Astha Hospital, Allahabad has a comprehensive diagnostic center or medical
                                        laboratory which is excellently committed in taking care of Patients’ Medical
                                        Test.
                                        We educate the Patient also about their diseases and test it with our various
                                        medical tools present in our hospital.
                                    </p>
                                    <a href="Pathology.html"><img src="images/Hospital/readmorebuttonblue.png"
                                            style="width:150px; height:55px; float:right; margin-top:-10px;">
                                    </a>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3 col-md-3 col-lg-3 sec3sub3 right_remove" data-wow-offset="200"
                        data-wow-delay="0.5s">
                        <ul class="nav nav-tabs">
                            <li class="active"><a data-toggle="tab" href="#popular">News</a></li>
                            <!--                    <li class=""><a data-toggle="tab" href="#recent">Events</a></li>
                    <li class=""><a data-toggle="tab" href="#comment">Free Check Ups</a></li>-->
                        </ul>
                        <div class="tab-content">
                            <!--popular posts-->
                            <div id="popular" class="fade in tab-pane tab_pane active">
                                <div class="col-md-12 col-xs-12 padding_remove tab_inner">
                                    <div class="col-md-4 col-xs-4 padding_remove">
                                        <img class="img-responsive pull-left" src="images/Operation_Dr_Amrita.jpg"
                                            alt="Tumor Operated">
                                    </div>
                                    <div class="col-md-8 col-xs-8">
                                        <div class="post-title-side">A Big Tumor has been taken out from the Patient Ms.
                                            Bharti Sharma by Dr. Amrita Agrahari (Obstetric & Gynecology Surgeon) on
                                            22.06.2018.</div>
                                        <!--                                <div class="post-date-side">August, 13th, 2016</div>-->
                                    </div>
                                </div>
                                <div class="col-md-12 col-xs-12 padding_remove tab_inner">
                                    <div class="col-md-4 col-xs-4 padding_remove">
                                        <a href="Press_Release.html">
                                            <img class="img-responsive pull-left" src="images/Operation%201.jpg"
                                                alt="Laproscopic Appendicectomy by Dr. Dhanesh Agrahari"></a>
                                    </div>
                                    <div class="col-md-8 col-xs-8" style="width:78%">
                                        <div class="post-title-side">Famous Pediatric Surgeon Dr. Dhanesh Agrahari
                                            successfully performed Laproscopic Appendicectomy of a 5 Year Old NRI Child
                                            in Astha Hospital, Allahabad. </div>
                                        <!--                               <div class="post-date-side">Jan, 30th, 2017</div> -->
                                    </div>
                                </div>
                                <div class="col-md-12 col-xs-12 padding_remove tab_inner">
                                    <div class="col-md-4 col-xs-4 padding_remove">
                                        <img class="img-responsive pull-left" src="images/Hospital/Hospital_Small.png"
                                            alt="">
                                    </div>
                                    <div class="col-md-8 col-xs-8">
                                        <div class="post-title-side">We have Launched our Website with User Friendly
                                            Features.</div>
                                        <!--                                <div class="post-date-side">April, 7th, 2014</div>-->
                                    </div>
                                </div>

                            </div><!--popular posts end-->

                            <!--Recent posts-->
                            <!--                    <div id="recent" class="tab-pane fade">

                        <div class="col-md-12 col-xs-12 padding_remove tab_inner">
                            <div class="col-md-4 col-xs-4 padding_remove">
                                <img class="img-responsive pull-left" src="images/blog-dummy-3-3.jpg" alt="">
                            </div>
                            <div class="col-md-8 col-xs-8">
                                <div class="post-title-side">Etiam tristique niba</div>
                                <div class="post-date-side">April, 7th, 2014</div>
                            </div>
                        </div>
                        <div class="col-md-12 col-xs-12 padding_remove tab_inner">
                            <div class="col-md-4 col-xs-4 padding_remove">
                                <img class="img-responsive pull-left" src="images/blog-dummy-3-3.jpg" alt="">
                            </div>
                            <div class="col-md-8 col-xs-8">
                                <div class="post-title-side">Etiam tristique niba</div>
                                <div class="post-date-side">April, 7th, 2014</div>
                            </div>
                        </div>

                        <div class="col-md-12 col-xs-12 padding_remove tab_inner">
                            <div class="col-md-4 col-xs-4 padding_remove">
                                <img class="img-responsive pull-left" src="images/blog-dummy-3-3.jpg" alt="">
                            </div>
                            <div class="col-md-8 col-xs-8">
                                <div class="post-title-side">Etiam tristique niba</div>
                                <div class="post-date-side">April, 7th, 2014</div>
                            </div>
                        </div>

                    </div>Recent posts End-->

                            <!--Comments-->
                            <!--                    <div id="comment" class="tab-pane fade">

                        <div class="col-md-12 col-xs-12 padding_remove tab_inner">
                            <div class="col-md-4 col-xs-4 padding_remove">
                                <img class="img-responsive pull-left" src="images/blog-dummy-1.png" alt="">
                            </div>
                            <div class="col-md-8 col-xs-8">
                                <div class="post-title-side">Etiam tristique niba</div>
                                <div class="post-date-side">April, 7th, 2014</div>
                            </div>
                        </div>

                        <div class="col-md-12 col-xs-12 padding_remove tab_inner">
                            <div class="col-md-4 col-xs-4 padding_remove">
                                <img class="img-responsive pull-left" src="images/blog-dummy-3.png" alt="">
                            </div>
                            <div class="col-md-8 col-xs-8">
                                <div class="post-title-side">Etiam tristique niba</div>
                                <div class="post-date-side">April, 7th, 2014</div>
                            </div>
                        </div>

                        <div class="col-md-12 col-xs-12 padding_remove tab_inner">
                            <div class="col-md-4 col-xs-4 padding_remove">
                                <img class="img-responsive pull-left" src="images/blog-dummy-1.png" alt="">
                            </div>
                            <div class="col-md-8 col-xs-8">
                                <div class="post-title-side">Etiam tristique niba</div>
                                <div class="post-date-side">April, 7th, 2014</div>
                            </div>
                        </div>
                    </div>Comments end-->

                        </div><!-- Tab panes end-->
                    </div>

                </div>
            </div>
        </section>
        <!-- OUR DEPARTMENT -->

        <section class="sec4 animatedParent">
            <div class="container">
                <div class="row">
                    <h3 class="secheadng2">Our Hospital Specialties</h3>
                    <div class="col-sm-12 col-xs-12 col-md-4 col-lg-4 padding_remove">
                        <img alt="" src="images/what-we-do-best.jpg" alt="image" class="thumbnail" width="100%">
                    </div>
                    <div class="col-sm-12 col-xs-12 col-md-8 col-lg-8">
                        <div class="row">
                            <div class="col-sm-12 col-xs-12 col-md-4 col-lg-4 departmnt_sec">
                                <div data-wow-offset="150" data-wow-delay="0.6s"
                                    class="icon-box-11 wow fadeInUp animated animated"
                                    style="visibility: visible;-webkit-animation-delay: 0.6s; -moz-animation-delay: 0.6s; animation-delay: 0.6s;">
                                    <div class="icon-boxwrap2">
                                        <i class="fa fa-user-md icon-box-back2"></i>
                                    </div>
                                    <div class="icon-box2-title">
                                        Oxygen Plant
                                    </div>

                                    <p>in Astha Hospital</p>
                                    <div class="iconbox-readmore"><a href="Oxygen_Plant.html">Read More</a></div>
                                </div>
                            </div>
                            <div class="col-sm-12 col-xs-12 col-md-4 col-lg-4 departmnt_sec">
                                <div data-wow-offset="150" data-wow-delay="0.6s"
                                    class="icon-box-12 wow fadeInUp animated animated"
                                    style="visibility: visible;-webkit-animation-delay: 0.6s; -moz-animation-delay: 0.6s; animation-delay: 0.6s;">
                                    <div class="icon-boxwrap2"><i class="fa fa-stethoscope icon-box-back2"></i></div>
                                    <div class="icon-box2-title">
                                        Water Treatment Plant
                                    </div>
                                    <p>in Astha Hospital</p>
                                    <div class="iconbox-readmore"><a href="Water_Treatment.html">Read More</a></div>
                                </div>
                            </div>
                            <div class="col-sm-12 col-xs-12 col-md-4 col-lg-4 departmnt_sec">
                                <div data-wow-offset="150" data-wow-delay="0.6s"
                                    class="icon-box-13 wow fadeInUp animated animated"
                                    style="visibility: visible;-webkit-animation-delay: 0.6s; -moz-animation-delay: 0.6s; animation-delay: 0.6s;">
                                    <div class="icon-boxwrap2"><i class="fa fa-medkit icon-box-back2"></i></div>
                                    <div class="icon-box2-title">
                                        Solar Panel Plant
                                    </div>
                                    <p>in Astha Hospital</p>
                                    <div class="iconbox-readmore"><a href="Solar_Panel.html">Read More</a></div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12 col-xs-12 col-md-4 col-lg-4 departmnt_sec">
                                <div data-wow-offset="150" data-wow-delay="0.6s"
                                    class="icon-box-14 wow fadeInUp animated animated"
                                    style="visibility: visible;-webkit-animation-delay: 0.6s; -moz-animation-delay: 0.6s; animation-delay: 0.6s;">
                                    <div class="icon-boxwrap2"><i class="fa fa-user-md icon-box-back2"></i></div>
                                    <div class="icon-box2-title">
                                        Power Back Up Plant
                                    </div>
                                    <p>in Astha Hospital</p>
                                    <div class="iconbox-readmore"><a href="Power_BackUp_Plant.html">Read More</a></div>
                                </div>
                            </div>
                            <div class="col-sm-12 col-xs-12 col-md-4 col-lg-4 departmnt_sec">
                                <div data-wow-offset="150" data-wow-delay="0.6s"
                                    class="icon-box-15 wow fadeInUp animated animated"
                                    style="visibility: visible;-webkit-animation-delay: 0.6s; -moz-animation-delay: 0.6s; animation-delay: 0.6s;">
                                    <div class="icon-boxwrap2"><i class="fa fa-stethoscope icon-box-back2"></i></div>
                                    <div class="icon-box2-title">
                                        Operation Theater Unit
                                    </div>
                                    <p>in Astha Hospital</p>
                                    <div class="iconbox-readmore"><a href="Operation_Unit.html">Read More</a></div>
                                </div>
                            </div>
                            <div class="col-sm-12 col-xs-12 col-md-4 col-lg-4 departmnt_sec">
                                <div data-wow-offset="150" data-wow-delay="0.6s"
                                    class="icon-box-16 wow fadeInUp animated animated"
                                    style="visibility: visible;-webkit-animation-delay: 0.6s; -moz-animation-delay: 0.6s; animation-delay: 0.6s;">
                                    <div class="icon-boxwrap2"><i class="fa fa-medkit icon-box-back2"></i></div>
                                    <div class="icon-box2-title">
                                        High End Dialysis Unit
                                    </div>
                                    <p>in Astha Hospital</p>
                                    <div class="iconbox-readmore"><a href="Dialysis_Unit.html">Read More</a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- OUR ACHIEVEMENTS -->

        <section class="sec5">
            <div class="container">
                <div class="row">
                    <h3 class="secheadng2">Our Departments
                        <a href="Departments.html" style="float:right; font-size: 15px;">View All</a>
                    </h3>
                    <div class="col-xs-12 col-md-12 col-lg-12 padding_remove" id="slider">
                        <!-- Top part of the slider -->
                        <div class="row">
                            <div class="col-sm-8" id="carousel-bounding-box">
                                <div class="carousel slide" id="myCarousel">
                                    <!-- Carousel items -->
                                    <div class="carousel-inner ach_slider">

                                        <div class="active item" data-slide-number="0">
                                            <img src="images/Department/Neurosurgery_Department.png">
                                        </div>

                                        <div class="item" data-slide-number="1">
                                            <img src="images/Hospital/Pediatric_Department.png">
                                        </div>

                                        <div class="item" data-slide-number="3">
                                            <img src="images/Department/Gastroenterology_Department.jpg">
                                        </div>

                                        <div class="item" data-slide-number="2">
                                            <img src="images/Department/PediatricDepartment%26Neonatal.png">
                                        </div>

                                        <div class="item" data-slide-number="4">
                                            <img src="images/Department/Nephrology_Department.jpg">
                                        </div>

                                        <div class="item" data-slide-number="6">
                                            <img src="images/Department/Pain_Management_Banner1.png">
                                        </div>

                                        <div class="item" data-slide-number="5">
                                            <img src="images/Department/Urology_Department_Small.png">
                                        </div>

                                        <div class="item" data-slide-number="8">
                                            <img src="images/Department/Minimal_Access_Department.jpg">
                                        </div>

                                        <div class="item" data-slide-number="7">
                                            <img src="images/Department/Obstetrics_and_Gynaecology_Department.png">
                                        </div>

                                        <div class="item" data-slide-number="9">
                                            <img src="images/Department/Anesthesia_Department.jpg">
                                        </div>




                                    </div><!-- Carousel nav -->
                                    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
                                        <span class="glyphicon glyphicon-chevron-left"></span>
                                    </a>
                                    <a class="right carousel-control" href="#myCarousel" role="button"
                                        data-slide="next">
                                        <span class="glyphicon glyphicon-chevron-right"></span>
                                    </a>
                                </div>
                            </div>

                            <div class="col-sm-4" id="carousel-text"></div>

                            <div id="slide-content" style="display: none;">
                                <div id="slide-content-0">
                                    <h2 style="margin-top:0px; color:red; font-size: 18px;">Department of Neuro Surgery
                                    </h2>
                                    <p style="border-bottom: 1px solid grey; text-align: justify;">Dr. Sanjay Asthana -
                                        M.S. | M.Ch. (Neurosurgery)</p>
                                    <p style="text-align: justify">
                                        - State that the surgery performed on the nervous system, especially in the
                                        brain and spinal cord. Neurosurgery (or neurological surgery) is the medical
                                        specialty concerned with the prevention, diagnosis, treatment, and
                                        rehabilitation of disorders which affect of any
                                        portion of the nervous system including the brain, spinal cord, peripheral
                                        nerves, and extra-cranial cerebrovascular system.
                                        We also offer a structured rehabilitation program helped by team of
                                        Physiotherapist including laser therapy.
                                        Our Brain & Spine Care Team is focused on providing you only the best in Neuro
                                        Department in this zone.
                                    </p>
                                    <a href="Neurosurgery_Department.html">
                                        <img src="images/Hospital/readmorebuttonblue.png"
                                            style="width:150px; height:55px; float:right; margin-top:-25px;">
                                    </a>
                                </div>

                                <div id="slide-content-1">
                                    <h2 style="margin-top:0px; color:red; font-size: 18px;">Department of Pediatric
                                        Surgery </h2>
                                    <p style="border-bottom: 1px solid grey; text-align: justify;">
                                        Dr. Dhanesh Kr. Agrahari - M.S. | M.Ch. (Pediatric Surgery)</p>
                                    <p style="text-align: justify">
                                        - State that its a subspecialty of surgery involving the surgery of fetuses,
                                        infants, children, adolescents, and teens. Subspecialties of pediatric surgery
                                        itself include: Neonatal Surgery and Fetal Surgery, Pediatric Gastro-Intenstinal
                                        Surgery, Pediatric Urology, Pediatric Plastic Surgery, Pediatric Neuro-Surgery,
                                        etc.
                                        We provide a wide range of child care services mainly to highlight Pediatric
                                        Laproscopic Surgery in Children which is established and having expertise at
                                        very less centers in North India. Astha Hospital in Allahabad is one of those
                                        centers where this Laparoscopic Surgery is being done successfully.

                                    </p>
                                    <a href="Pediatric_Surgery.html">
                                        <img src="images/Hospital/readmorebuttonblue.png"
                                            style="width:150px; height:55px; float:right; margin-top:-25px;">
                                    </a>

                                </div>

                                <div id="slide-content-2">
                                    <h2 style="margin-top:0px; color:red; font-size: 18px;">Department of Pediatric &
                                        Neonatal </h2>
                                    <p style="border-bottom: 1px solid grey; text-align: justify;">
                                        Dr. J. V. Rai - M.D. | MRCP (Pediatrics)<br>
                                        Dr. Shubha Malviya - DCH (Pediatrics)
                                    </p>
                                    <p style="text-align: justify">
                                        - State that its a subspecialty of surgery involving the surgery of fetuses,
                                        infants, children, adolescents, and teens. Subspecialties of pediatric surgery
                                        itself include: Neonatal Surgery and Fetal Surgery, Pediatric Gastro-Intenstinal
                                        Surgery, Pediatric Urology, Pediatric Plastic Surgery, Pediatric Neuro-Surgery,
                                        etc.
                                        We provide a wide range of child care services mainly to highlight Pediatric
                                        Laproscopic Surgery in Children which is established and having expertise at
                                        very less centers in North India. Astha Hospital in Allahabad is one of those
                                        centers where this Laparoscopic Surgery is being done successfully.

                                    </p>
                                    <a href="Pediatric_Department.html">
                                        <img src="images/Hospital/readmorebuttonblue.png"
                                            style="width:150px; height:55px; float:right; margin-top:-25px;">
                                    </a>
                                </div>

                                <div id="slide-content-3">
                                    <h2 style="margin-top:0px; color:red; font-size: 18px;">Department of
                                        Gastroenterology</h2>
                                    <p style="border-bottom: 1px solid grey; text-align: left;">Dr. Alok Mishra - M.D. |
                                        D.M. (Gastroenterology)</p>
                                    <p style="text-align: justify">
                                        - State that the branch of medicine which deals with disorders of the Stomach
                                        and Intestines. Gastroenterology is the branch of medicine
                                        focused on the digestive system and its disorders. Diseases affecting the
                                        gastrointestinal tract,
                                        which include the organs from mouth to anus, along the alimentary canal, are the
                                        focus of this Speciality.
                                        <br>
                                        We Specialises in
                                        • Endoscopy Services which includes<br>
                                        • Upper GI Procedure <br> Lower GI Procedure<br>
                                        • Endoscopic Retrograde Cholangiopancretography (ERCP) Capsule Endoscope
                                    </p>
                                    <a href="Gastero_Department.html">
                                        <img src="images/Hospital/readmorebuttonblue.png"
                                            style="width:150px; height:55px; float:right; margin-top:-25px;">
                                    </a>
                                </div>

                                <div id="slide-content-4">
                                    <h2 style="margin-top:0px; color:red; font-size: 18px;">Department of Nephrology
                                    </h2>
                                    <p style="border-bottom: 1px solid grey; text-align: left;">Dr. A. Gupta - M.D. |
                                        DNB (Nephrology)</p>
                                    <p style="text-align: justify">
                                        - States that the branch of medicine which deals with the Physiology and
                                        Diseases of the Kidneys. Nephrology department of Astha Hospital is amongst
                                        one of the pioneer center of its
                                        kind & will play a profound role in management of critically ill patients. This
                                        department is concerned with the diagnosis and treatment of kidney diseases,
                                        including electrolyte disturbances and hypertension,
                                        Diabetes and care of those requiring renal replacement therapy, including
                                        dialysis and renal transplantation.
                                    </p>
                                    <a href="Nephrology_Department.html">
                                        <img src="images/Hospital/readmorebuttonblue.png"
                                            style="width:150px; height:55px; float:right; margin-top:-25px;">
                                    </a>
                                </div>

                                <div id="slide-content-5">
                                    <h2 style="margin-top:0px; color:red; font-size: 18px;">Department of Urology</h2>
                                    <p style="border-bottom: 1px solid grey; text-align: left;">Dr. Vibhav Malviya -
                                        M.S. | M.Ch. (Urology)</p>
                                    <p style="text-align: justify">
                                        - State that the branch of medicine that focuses on Surgical and Medical
                                        diseases of the Male and Female Urinary Tract System and the Male Reproductive
                                        Organs. Its aso known as Genitourinary Surgery.
                                        The organs under the domain of Urology include the Kidneys, Adrenal Glands,
                                        Ureters, Urinary Bladder, Urethra and the Male Reproductive Organs (Testes,
                                        Epididymis, vas Deferens, Seminal Vesicles, Prostate and Penis).
                                        The urinary and reproductive tracts are closely linked, and disorders of one
                                        often affect the other. Thus, a major spectrum of the conditions managed in
                                        urology exists under the domain of genitourinary disorders.
                                    </p>
                                    <a href="Urology_Department.html">
                                        <img src="images/Hospital/readmorebuttonblue.png"
                                            style="width:150px; height:55px; float:right; margin-top:-25px;">
                                    </a>
                                </div>

                                <div id="slide-content-6">
                                    <h2 style="margin-top:0px; color:red; font-size: 18px;">Department of Pain
                                        Management</h2>
                                    <p style="border-bottom: 1px solid grey; text-align: left;">Dr. Rupam Sinha - M.D.

                                    </p>
                                    <p style="text-align: justify">
                                        - is a branch of medicine employing an interdisciplinary approach for easing the
                                        suffering and improving the
                                        quality of life of those living with Chronic Pain. In Astha under Pain
                                        Management Department, we deals with all
                                        kinds of Back Pain, Headache, CRPS, Shingles, Chronic Abdominal & Pelvi Pain,
                                        Neuropethic Pain (in Diabetes), Cancer,
                                        Muscular & Joint Pain & Painless Normal Deliveries.
                                        Some of them are:-<br>
                                        • Control of Acute & Chronic Pain.<br>
                                        • Various Blocks to treat different types of Pain.<br>
                                        • Neuralgias and Neuropathic Pain including that of due to Diabetes.
                                    </p>
                                    <a href="Pain_Management.html">
                                        <img src="images/Hospital/readmorebuttonblue.png"
                                            style="width:150px; height:55px; float:right; margin-top:-25px;">
                                    </a>
                                </div>
                                <div id="slide-content-7">
                                    <h2 style="margin-top:0px; color:red; font-size: 18px;">Department of Gynaecology
                                        and Obstetrics</h2>
                                    <p style="border-bottom: 1px solid grey; text-align: left;">Dr. Amrita Madhab
                                        Agrahari - DGO | FICMCH
                                        | Dr. Smita Srivastava - DGO, DNB | Dr. Urmi Neogi - M.S. <br>

                                    </p>
                                    <p style="text-align: justify">
                                        - State that the branch of Physiology and Medicine which deals with the
                                        Functions and Diseases specific to women and girls, especially those affecting
                                        the reproductive system.
                                        Astha Hospital is committed to provide best health care for women seeking
                                        gynecology solutions. Our team of experts
                                        ensures expectant women and couples seeking fertility treatment experience
                                        superior health care benefits and services.
                                        Our specialized team provides advanced fertility solutions to couples struggling
                                        to achieve pregnancy.
                                    </p>
                                    <a href="Gynecology_Department.html">
                                        <img src="images/Hospital/readmorebuttonblue.png"
                                            style="width:150px; height:55px; float:right; margin-top:-25px;">
                                    </a>

                                </div>
                                <div id="slide-content-8">
                                    <h2 style="margin-top:0px; color:red; font-size: 18px;">Department of General &
                                        Minimal Access Surgery</h2>
                                    <p style="border-bottom: 1px solid grey; text-align: left;">Dr. P. Neogi - M.S. FRCS

                                    </p>
                                    <p style="text-align: justify">
                                        - Minimal access surgery implies that a limited incision length or limited
                                        number of small incisions in the abdominal wall
                                        are used to gain access to the organs within the abdomen.
                                        minimal access surgery (minimally invasive surgery) a surgical procedure done in
                                        a manner that causes little or
                                        no trauma or injury to the patient, such as through a cannula using lasers,
                                        endoscopes, or laparoscopes;
                                        compared with other procedures, those in this category involve less bleeding,
                                        smaller amounts of anesthesia, less pain, and minimal scarring.

                                    </p>
                                    <a href="General_Access_Minimal_Department.html">
                                        <img src="images/Hospital/readmorebuttonblue.png"
                                            style="width:150px; height:55px; float:right; margin-top:-15px;">
                                    </a>
                                </div>
                                <div id="slide-content-9">
                                    <h2 style="margin-top:0px; color:red; font-size: 18px;">Department of Anaesthesia &
                                        Critical Care Medicine </h2>
                                    <p style="border-bottom: 1px solid grey; text-align: left;">Dr. Alpana Sharma - M.D.
                                        (Anaesthesia)
                                    </p>
                                    <p style="text-align: justify">
                                        - State that Anesthesia is the use of medicine to prevent or Reduce the Feeling
                                        of Pain or Sensation during Surgery or other Painful Procedures (such as getting
                                        stitches).
                                        Anesthesia enables the painless performance of medical procedures that would
                                        cause severe or intolerable pain to an unanesthetized Patient.
                                    </p>
                                    <a href="Anesthesia_Department.html">
                                        <img src="images/Hospital/readmorebuttonblue.png"
                                            style="width:150px; height:55px; float:right; margin-top:-25px;">
                                    </a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="sec4">
            <div class="container">
                <div class="row">
                    <h3 class="secheadng2">Testimonials</h3>
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 padding_remove" style="background: #ffffff;">

                        <article>
                            <div id="owl">

                                <div class="column row">
                                    <div class="large-12 columns testimonial">
                                        <div class="row">
                                            <div class="col-sm-2 col-md-2 col-lg-2">
                                                <div class="student">
                                                    <div class="photo">
                                                        <img src="images/Hospital/Testimonial.jpg"
                                                            style="width: 100%; border-radius: 100%;vertical-align: middle;height: auto; max-width: 100%;"
                                                            class="round-image">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-sm-10 col-md-10 col-lg-10">
                                                <p style="text-align: justify;width:95%;">
                                                    <i class="fa fa-quote-left quote-left"></i>&nbsp;
                                                    I am very happy for such a Well-Maintained with High Standard
                                                    Facilities Hospital situated in our Allahabad City. I visited the
                                                    Hospital on June, 2016 for the treatment and I am totally satisfied
                                                    with the treatment and the service by the hospital. Very much
                                                    pleased
                                                    with all the Staffs and their Care.
                                                    <i class="fa fa-quote-right quote-right"></i>
                                                </p>
                                                <h5><strong>Surabhi Jain,</strong>&nbsp; Allahabad</h5>
                                            </div>
                                        </div>
                                        <a href="Testimonials.html">
                                            <img style="width:150px; height:55px; float:right; margin-top:-10px;"
                                                src="images/Hospital/readmorebuttonblue.png">
                                        </a>
                                    </div>
                                </div>

                                <div class="column row">
                                    <div class="large-12 columns testimonial">
                                        <div class="row">
                                            <div class="col-sm-2 col-md-2 col-lg-2">
                                                <div class="student">
                                                    <div class="photo">
                                                        <img src="images/Hospital/Testimonial.jpg"
                                                            style="width: 100%; border-radius: 100%;vertical-align: middle;height: auto; max-width: 100%;"
                                                            class="round-image">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-sm-10 col-md-10 col-lg-10">
                                                <p style="text-align: justify;width:95%;">
                                                    <i class="fa fa-quote-left quote-left"></i>&nbsp;
                                                    Experience of mine in Astha Hospital was really good and well
                                                    above medical treatment standards. The Doctors, Consultants, Nurses
                                                    and Staff successfully diagnosed (my disease)
                                                    with unbelievable care and compassion. Their attention to ensuring
                                                    my well-being was exceptional.
                                                    <i class="fa fa-quote-right quote-right"></i>
                                                </p>
                                                <h5><strong>Amit Saini </strong>Allahabad</h5>
                                            </div>
                                        </div>
                                        <a href="Testimonials.html">
                                            <img style="width:150px; height:55px; float:right; margin-top:-10px;"
                                                src="images/Hospital/readmorebuttonblue.png">
                                        </a>
                                    </div>
                                </div>

                                <div class="column row">
                                    <div class="large-12 columns testimonial">
                                        <div class="row">
                                            <div class="col-sm-2 col-md-2 col-lg-2">
                                                <div class="student">
                                                    <div class="photo">
                                                        <img src="images/Testimonial/Rajendra%20Prasad.jpg"
                                                            style="width: 100%; border-radius: 100%;vertical-align: middle;height: auto; max-width: 100%;"
                                                            class="round-image">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-sm-10 col-md-10 col-lg-10">
                                                <p style="text-align: justify;width:95%;">
                                                    <i class="fa fa-quote-left quote-left"></i>&nbsp;
                                                    "To Dr. Dhanesh Agrahari:- Sir, You have done surgery of my child
                                                    very successfully in December, 2008 on 2nd
                                                    day of her birth and she was very
                                                    serious due to tracheo-oesophagal fistula. But, now, she is
                                                    absolutely Healthy. I wish you a lot of Thanks.
                                                    <i class="fa fa-quote-right quote-right"></i>
                                                </p>
                                                <h5><strong>Dr. Rajendra Prasad Verma,</strong>&nbsp; Allahabad</h5>
                                            </div>
                                        </div>
                                        <a href="Testimonials.html">
                                            <img style="width:150px; height:55px; float:right; margin-top:-10px;"
                                                src="images/Hospital/readmorebuttonblue.png">
                                        </a>
                                    </div>
                                </div>


                            </div>
                        </article>

                    </div>
                </div>
            </div>
        </section>

        <section class="sec6">
            <div class="container-fluid">
                <div class="row">
                    <h3 class="secheadng3">Our Gallery
                        <a href="Gallery.html" style="float:right; font-size: 15px;">View All</a>
                    </h3>

                    <div class="col-sm-12 col-md-12 col-lg-12 padding_remove">
                        <div id="owl-demo2">
                            <div class="item">
                                <div class="feed-img2">
                                    <div class="clearfix">
                                        <a href="Gallery.html"><img src="images/Gallery/Front_Area.png" alt="Owl Image"
                                                class=""></a>
                                    </div>
                                    <div class="feed-btn2 indi-btn">
                                        <ul>
                                            <li class="bluee"><a href="Gallery.html">Astha Hospital</a>
                                                <p>Front View of Hospital</p>

                                            </li>

                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="feed-img2">
                                    <div class="clearfix">
                                        <a href="Gallery.html"><img src="images/Gallery/Reception.png" alt="Owl Image"
                                                class=""></a>
                                    </div>
                                    <div class="feed-btn2 indi-btn">
                                        <ul>
                                            <li class="bluee"><a href="Gallery.html">Astha Hospital</a>
                                                <p>Reception Area of Hospital</p>
                                                <p>You Can Make an Enquiry Here.</p>
                                            </li>

                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="feed-img2">
                                    <div class="clearfix">
                                        <a href="Gallery.html"><img src="images/Gallery/Lobby_Area.png" alt="Owl Image"
                                                class=""></a>
                                    </div>
                                    <div class="feed-btn2 indi-btn">
                                        <ul>
                                            <li class="bluee"><a href="Gallery.html">Astha Hospital</a>
                                                <p>Air - Conditioned Lobby Area</p>
                                                <p>Patient & Visitors Sitting Area</p>
                                            </li>

                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="feed-img2">
                                    <div class="clearfix">
                                        <a href="Gallery.html"><img src="images/Gallery/NICU.png" alt="Owl Image"
                                                class=""></a>
                                    </div>
                                    <div class="feed-btn2 indi-btn">
                                        <ul>
                                            <li class="bluee"><a href="Gallery.html">Astha Hospital</a>
                                                <p>Air - Conditioned 8 Bedded NICU Ward</p>
                                                <p>Pediatric Surgery Department</p>
                                            </li>

                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="feed-img2">
                                    <div class="clearfix">
                                        <a href="Gallery.html"><img src="images/Gallery/ICU.png" alt="Owl Image"
                                                class=""></a>
                                    </div>
                                    <div class="feed-btn2 indi-btn">
                                        <ul>
                                            <li class="bluee"><a href="#">Astha Hospital</a>
                                                <p>Air - Conditioned 16 Bedded ICU Ward</p>
                                                <p>Highly Intensive, Clean and 24*7*367 Service</p>
                                            </li>

                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="feed-img2">
                                    <div class="clearfix">
                                        <a href="Gallery.html"><img src="images/Gallery/Floor_Wise_Reception.png"
                                                alt="Owl Image" class=""></a>
                                    </div>
                                    <div class="feed-btn2 indi-btn">
                                        <ul>
                                            <li class="bluee"><a href="Gallery.html">Astha Hospital</a>
                                                <p>Air - Conditioned Floor Wise Area</p>
                                                <p>Floor Reception View</p>
                                            </li>

                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="feed-img2">
                                    <div class="clearfix">
                                        <a href="Gallery.html"><img src="images/Gallery/General_Ward.png"
                                                alt="Owl Image" class=""></a>
                                    </div>
                                    <div class="feed-btn2 indi-btn">
                                        <ul>
                                            <li class="bluee"><a href="Gallery.html">Astha Hospital</a>
                                                <p>General Ward</p>

                                            </li>

                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="feed-img2">
                                    <div class="clearfix">
                                        <a href="Gallery.html"><img src="images/Gallery/Semi_Private_Room.png"
                                                alt="Owl Image" class=""></a>
                                    </div>
                                    <div class="feed-btn2 indi-btn">
                                        <ul>
                                            <li class="bluee"><a href="Gallery.html">Astha Hospital</a>
                                                <p>Semi - Private Room</p>
                                                <p>Fully - Air Conditioned</p>
                                            </li>

                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- EVERYTHING YOU NEED -->

        <section class="sec7 animatedParent">
            <div class="container">
                <div class="row">
                    <h3 class="secheadng2">Everything you need</h3>
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 padding_remove">
                        <div class="col-md-3 col-lg-3 col-sm-6 left_remove wow fadeInLeft animated animated animated">
                            <div class="flip-box-wrap" style="margin-top: 0px;">
                                <div data-animation-delay="03" data-animation=""
                                    class="flip-box auto horizontal_flip_left">
                                    <div class="ifb-flip-box">

                                        <div class="ifb-face ifb-front" style="background: #FFFFFF;">
                                            <div class="flip-box-icon">
                                                <div data-animation-delay="03" data-animation="" class="aio-icon none">
                                                    <i class="flip-icons icon-heart"></i>
                                                </div>
                                            </div>
                                            <img src="images/Emergency_Icon.png">
                                            <h3 class="flip-box-head-txt">Emergency Number</h3>
                                            <p style="border-bottom: 1px solid red; ">Check Here.</p>
                                        </div><!-- END .front -->

                                        <div class="ifb-face ifb-back flip-backface">
                                            <h3 class="flip-box-head-txt">24*7*365</h3>
                                            <p>In Case of Emergency, Please Contact on Below Numbers.</p>
                                            <p>| +91 - 9838086888 | 0532 - 246414 | 0532 - 6455868 |</p>


                                        </div><!-- END .back -->

                                    </div> <!-- ifb-flip-box -->
                                </div> <!-- flip-box -->
                            </div>
                        </div>
                        <div class="col-md-3 col-lg-3 col-sm-6 wow fadeInLeft animated animated animated">
                            <div class="flip-box-wrap" style="margin-top: 0px;">
                                <div data-animation-delay="03" data-animation=""
                                    class="flip-box auto horizontal_flip_left">
                                    <div class="ifb-flip-box">

                                        <div class="ifb-face ifb-front" style="background: #FFFFFF;">
                                            <div class="flip-box-icon">
                                                <div data-animation-delay="03" data-animation="" class="aio-icon none ">
                                                    <i class="flip-icons icon-heart"></i>
                                                </div>
                                            </div>
                                            <img src="images/Opd_Icon.png">
                                            <h3 class="flip-box-head-txt">OPD Schedule</h3>
                                            <p style="border-bottom: 1px solid red; ">Check Here.</p>
                                        </div><!-- END .front -->

                                        <div class="ifb-face ifb-back flip-backface">

                                            <h3 class="flip-box-head-txt">Doctors OPD</h3>
                                            <p>Check the OPD Timing of the Doctors by Clicking Below.</p>
                                            <div class="flip_link"><a class="flip-read-more"
                                                    href="Doctor_Schedule.html">Click Here!</a></div>
                                        </div><!-- END .back -->

                                    </div> <!-- ifb-flip-box -->
                                </div> <!-- flip-box -->
                            </div>
                        </div>
                        <div class="col-md-3 col-lg-3 col-sm-6 wow fadeInLeft animated animated animated">
                            <div class="flip-box-wrap" style="margin-top: 0px;">
                                <div data-animation-delay="03" data-animation=""
                                    class="flip-box auto horizontal_flip_left">
                                    <div class="ifb-flip-box">

                                        <div class="ifb-face ifb-front" style="background: #FFFFFF;">
                                            <div class="flip-box-icon">
                                                <div data-animation-delay="03" data-animation="" class="aio-icon none ">
                                                    <i class="flip-icons icon-heart"></i>
                                                </div>
                                            </div>
                                            <img src="images/Visitors_timing.png">
                                            <h3 class="flip-box-head-txt">Visitors Timing</h3>
                                            <p style="border-bottom: 1px solid red; ">Check Here.</p>
                                        </div><!-- END .front -->

                                        <div class="ifb-face ifb-back flip-backface">
                                            <h3 class="flip-box-head-txt">For Patient & ICU Both</h3>
                                            <p>In Morning:- 6 AM to 8 AM</p>
                                            <p>In Afternoon:- 1 PM to 2 PM</p>
                                            <p>In Evening:- 6 PM to 8 PM</p>
                                        </div><!-- END .back -->

                                    </div> <!-- ifb-flip-box -->
                                </div> <!-- flip-box -->
                            </div>
                        </div>
                        <div class="col-md-3 col-lg-3 col-sm-6 right_remove wow fadeInLeft animated animated animated">
                            <div class="flip-box-wrap" style="margin-top: 0px;">
                                <div data-animation-delay="03" data-animation=""
                                    class="flip-box auto horizontal_flip_left">
                                    <div class="ifb-flip-box">

                                        <div class="ifb-face ifb-front" style="background: #FFFFFF;">
                                            <div class="flip-box-icon">
                                                <div data-animation-delay="03" data-animation="" class="aio-icon none ">
                                                    <i class="flip-icons icon-heart"></i>
                                                </div>
                                            </div>
                                            <img src="images/Direction_Icon.png">
                                            <h3 class="flip-box-head-txt">Direction</h3>
                                            <p style="border-bottom: 1px solid red; ">Check Here.</p>
                                        </div><!-- END .front -->

                                        <div class="ifb-face ifb-back flip-backface">
                                            <h3 class="flip-box-head-txt">Reach Us</h3>
                                            <p>Check the Direction Over Map to Reach Us.</p>
                                            <div class="flip_link"><a class="flip-read-more"
                                                    href="Address_and_Direction_Map.html">Click Here !</a></div>
                                        </div><!-- END .back -->

                                    </div> <!-- ifb-flip-box -->
                                </div> <!-- flip-box -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

<?php include "include/footer.php"; ?>